#include <iostream>
#include <string.h>
#include <fstream>
#include <deque>

using namespace std;

ifstream citire_matricea_Romaniei("harta_Romaniei.in");
ifstream km_intre_orase("km_intre_orase.in");
ifstream nume_orase("orase.in");


int numar_orase,matricea_adiacenta[100][100];
void citirea()
{
    citire_matricea_Romaniei>>numar_orase;
    int x,y;
    while (citire_matricea_Romaniei>>x>>y)
    {   int km;
        km_intre_orase>>km;
        matricea_adiacenta[x][y]=matricea_adiacenta[y][x]=km;
    }
}

void afisare()
{
    for (int i=1;i<=numar_orase;i++)
    {   for (int j=1;j<=numar_orase;j++)
            cout<<matricea_adiacenta[i][j]<<" ";
        cout<<endl;
    }
    cout<<endl<<endl<<endl;
}




int start,destinatie;

const int oo=(1<<30);

int verificat[100];

deque<int>nefolositi;
pair<int,int> D[100];
void Dijkstra()
{
    while (nefolositi.front())
        nefolositi.pop_front();

    int q=0;

    for (int i=1;i<=numar_orase;i++)
        D[i].first=oo;
    D[start].first=0;


    bool ok=false;
    int i=start;
    while (i)
    {
        pair<int,int>minim;
        minim.first=oo;

        for (int j=1;j<=numar_orase;j++)
        {   if (matricea_adiacenta[i][j]&&verificat[j]==0)
            {
                //nefolositi.push_back(j);
                q++;
                if (matricea_adiacenta[i][j]<minim.first)
                    {minim.first=matricea_adiacenta[i][j];minim.second=j;}

                if (D[i].first+matricea_adiacenta[i][j]<D[j].first)
                    {
                        D[j].first=D[i].first+matricea_adiacenta[i][j];
                        D[j].second=i;

                    }
            }
        }

        /*
        for (int l=1;l<=q;l++)
        {
            if (nefolositi.front()==minim.second)
                nefolositi.pop_front();
            else
            {
                nefolositi.push_back(nefolositi.front());
                nefolositi.pop_front();
            }
        }
        */

        verificat[i]=1;



        if (minim.first!=oo)
            i=minim.second;
        else
            break;


    }


    /*
    while (nefolositi.front())
    {
        cout<<nefolositi.front()<<" ";
        nefolositi.pop_front();
    }

    cout<<endl<<endl;
    */


    for (int i=1;i<=numar_orase;i++)
        if (verificat[i]==0)
            {cout<<i<<" ";nefolositi.push_front(i);}

    cout<<endl;




    ok=false;
    while (nefolositi.front())
    {
        int i=nefolositi.front();
        nefolositi.pop_front();


        pair<int,int>minim;
        minim.first=oo;

        for (int j=1;j<=numar_orase;j++)
        {   if (matricea_adiacenta[i][j]&&verificat[j]==0)
            {
                //nefolositi.push_back(j);
                if (matricea_adiacenta[i][j]<minim.first)
                    {minim.first=matricea_adiacenta[i][j];minim.second=j;}

                if (D[i].first+matricea_adiacenta[i][j]<D[j].first)
                    {
                        D[j].first=D[i].first+matricea_adiacenta[i][j];
                        D[j].second=i;

                    }
            }
        }

        /*
        for (int l=1;l<=q;l++)
        {
            if (nefolositi.front()==minim.second)
                nefolositi.pop_front();
            else
            {
                nefolositi.push_back(nefolositi.front());
                nefolositi.pop_front();
            }
        }
        */

        verificat[i]=1;



        if (minim.first!=oo)
            i=minim.second;
        else
            break;


    }




}


char orase[100];
void citire_orase()
{
    nume_orase.get(orase,100);
}

deque<int>cod_oras;
void afisare_ruta()
{
    while (cod_oras.front())
    {
        int i=0,q=1;;
        bool validare,ok=false;
        while (orase[i]!=0)
        {
            if (orase[i-1]==32&&orase[i]!=32)
                q++;

            if (q==cod_oras.front()&&orase[i]!=32)
                {cout<<orase[i];ok=true;validare=true;}
            else
                validare=false;
            if (validare=false&&ok==true)
                break;
            i++;

        }
        cout<<" "<<D[cod_oras.front()].first<<" km";
        cout<<endl;
        cod_oras.pop_front();

    }
}


void codare_orase()
{
    char oras_start[100],oras_destinatie[100];

    cout<<"Orasul in care te afli: ";
    cin>>oras_start;
    cout<<"Oras la care vrei sa ajungi: ";
    cin>>oras_destinatie;

    citire_orase();

    int i=0,q=0,inceput_oras=0,sfarsit_oras;
    while (orase[i]!=0)
    {
        if (orase[i-1]==32&&orase[i]!=32||i==0&&orase[i]!=32)
        {       q++;
                inceput_oras=i;
                cout<<i<<" "<<inceput_oras<<"  | "<<q<<endl;
        }
        else
            if (orase[i]==32)
            {   bool ok_oras_start=true,ok_oras_destinatie=true;
                for (int j=inceput_oras;j<i;j++)
                {   if (orase[j]!=oras_start[j-inceput_oras])
                        ok_oras_start=false;
                    if (orase[j]!=oras_destinatie[j-inceput_oras])
                        ok_oras_destinatie=false;
                }
                if (ok_oras_start==true)
                    start=q;
                if (ok_oras_destinatie==true)
                    destinatie=q;
            }

        i++;
    }
}

int main()
{
    codare_orase();

    cout<<"* "<<start<<" "<<destinatie<<endl<<endl<<endl<<endl;







    while (cod_oras.front())
        cod_oras.pop_front();




    citirea();
    afisare();

//==============================================================================================



    Dijkstra();


    for (int i=1;i<=numar_orase;i++)
        cout<<D[i].first<<" ";
    cout<<endl<<endl;
    for (int i=1;i<=numar_orase;i++)
        cout<<D[i].second<<" ";
    cout<<endl<<endl;






    cod_oras.push_front(destinatie);
    bool ok=false;
    while (ok==false)
    {
        //cout<<D[destinatie].second<<" ";
        cod_oras.push_front(D[destinatie].second);
        destinatie=D[destinatie].second;
        if (destinatie==start)
            ok=true;
    }

/*
    while (cod_oras.front())
    {   cout<<cod_oras.front()<<" ";
        cod_oras.pop_front();
    }
*/


    cout<<"Ruta:"<<endl;
    afisare_ruta();









    //if (start>destinatie)
      //  swap(destinatie,start);

    //cout<<destinatie<<" ";



    /*
    while (start<destinatie)
    {
        cout<<D[destinatie].second<<" ";
        destinatie=D[destinatie].second;
    }
    */

    //cout<<endl<<start<<" "<<destinatie<<endl<<endl;


    /*
    while (start>destinatie)
    {
        for (int i=1;i<=numar_orase;i++)
            if (D[i].second==destinatie&&i==start)
            {
                cout<<i<<" ";
                start=D[i].second;
            }
    }
    */




//==============================================================================================




    return 0;
}
