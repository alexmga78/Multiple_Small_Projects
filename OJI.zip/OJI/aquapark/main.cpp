#include <iostream>
#include <fstream>
#include <queue>

using namespace std;

ifstream f("aquapark.in");
ofstream g("aquapark.out");

int a[100][100];
queue<int>que1;
queue<int>que2;

void afisare(int n)
{   for (int i=1;i<=n;i++)
    {   for (int j=1;j<=n;j++)
            cout<<a[i][j]<<" ";
        cout<<endl;
    }
    cout<<endl<<endl;
}


int main()
{   int c,n,m;
    f>>c>>n>>m;
    //int a[n][n];
    int x,y;
    for (int i=1;i<=m;i++)
        {f>>x>>y;que1.push(x);que2.push(y);}

    //afisare(n);

    if (c==2)
{       int N=m-4;
        N=N*(N+1)+2;
        cout<<N%666013;
}
    else
{       for (int i=1;i<=n/2;i++)
        {   cout<<que1.front()<<" "<<que2.front()<<" "<<1<<endl;
            que1.pop();
            que2.pop();
        }
        for (int i=n/2;i<=n;i++)
        {   cout<<que1.front()<<" "<<que2.front()<<" "<<2<<endl;
            que1.pop();
            que2.pop();
        }

}


    return 0;
}
