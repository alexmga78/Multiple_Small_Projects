#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

ifstream f("tairos.in");
ofstream g("tairos.out");

int a[100][100];

void afisare(int N)
{   for (int i=1;i<=N;i++)
    {   for (int j=1;j<=N;j++)
            cout<<a[i][j]<<" ";
        cout<<endl;
    }
    cout<<endl<<endl<<endl<<endl;
}

int main()
{   int N,D;
    f>>N>>D;
    //int a[N][N],
    int x,y;
    for (int i=1;i<=N;i++)
        {f>>x>>y;a[x][y]=a[y][x]=1;}

    afisare(N);

    int nr_ramuri=0;
    for (int i=1;i<=N;i++)
    {   bool ok=true;
        for (int j=i+1;j<=N;j++)
            if (a[i][j]==1)
                {ok=false;break;}
        bool Ok=false;
        for (int j=1;j<=i-1;j++)
            if (a[i][j]==1)
                Ok=true;
        if (ok==true&&Ok==true)
            nr_ramuri++;
    }
    cout<<nr_ramuri<<" "<<D<<" "<<N<<endl;

    int puncte_in_urma=0;
    for (int i=1;i<=D;i++)
        puncte_in_urma+=pow(nr_ramuri,i-1);
    puncte_in_urma*=N-nr_ramuri;
    int rezultat=pow(nr_ramuri,D)*N+puncte_in_urma;
    cout<<pow(nr_ramuri,D)*N<<" "<<puncte_in_urma<<endl<<endl;
    cout<<rezultat<<endl;
    rezultat=rezultat%1000000007;
    cout<<rezultat;

    return 0;
}
