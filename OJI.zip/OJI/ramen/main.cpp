#include <iostream>
#include <fstream>
#include <queue>

using namespace std;

ifstream f("ramen.in");
ofstream g("ramen.out");

int main()
{   int N,D;
    f>>N>>D;
    int T[N],P[N];
    for (int i=1;i<=N;i++)
        f>>T[i]>>P[i];
/*
//afisare=================================
    for (int i=1;i<=N;i++)
        cout<<T[i]<<" "<<P[i]<<endl;
    cout<<endl<<endl<<endl;
//afisare=================================
*/
    queue<int>que;
    int c[N];

//formarea randului=======================
    for (int i=1;i<=N;i++)
        que.push(T[i]+D);
//formarea randului=======================

//calcularea lui c[i]=====================
    for (int i=1;i<=N;i++)
        c[i]=T[i]-P[i]-D;
    /*cout<<"c[i]:"<<endl;
    for (int i=1;i<=N;i++)
        cout<<c[i]<<" ";
    cout<<endl<<endl<<endl;*/
//calcularea lui c[i]=====================

//formarea lui b[i]=======================
    for (int i=1;i<=N;i++)
        for (int j=i+1;j<=N;j++)
            if (P[i]>P[j])
                {swap(P[i],P[j]);swap(c[i],c[j]);}
    /*cout<<"b[i]:"<<endl;
    for (int i=1;i<=N;i++)
        cout<<P[i]<<" ";
    cout<<endl<<"c[i]:"<<endl;
    for (int i=1;i<=N;i++)
        cout<<c[i]<<" ";
    cout<<endl<<endl<<endl;*/
//formarea lui b[i]=======================

//raspuns final===========================
    for (int i=1;i<=N;i++)
    {   if (que.front()>=c[i])
        {   cout<<P[i]+que.front()<<endl;
            que.pop();
        }
        else
        {   int q=0;
            int j=i+1,start,finish;
            bool ok=false;
            while (ok==false)
            {
           start=j;
                while (P[j]==P[i+1])
                    {q++;j++;}
                finish=q+j-1;
                for (int j=start;j<=finish;j++)
                    if (c[j]<=que.front())
                        {ok=true;break;}
                /*cout<<q<<" "<<j<<" "<<finish<<endl;*/
                if (ok==false)
                    j=finish+1;
                /*cout<<j<<" "<<ok<<endl;*/
            }
            /*cout<<q<<endl<<endl;*/
            for (int j=start;j<finish;j++)
                for (int h=start;h<=finish;h++)
                    if (c[j]>c[h])
                        {swap(c[j],c[h]);swap(P[j],P[h]);}

            /*cout<<"b[i]:"<<endl;
            for (int i=1;i<=N;i++)
                cout<<P[i]<<" ";
            cout<<endl<<"c[i]:"<<endl;
            for (int i=1;i<=N;i++)
                cout<<c[i]<<" ";
            cout<<endl<<endl<<endl;*/

            //swap(c[i],c[start]);
            //swap(P[i],P[start]);

            int stocare1=P[start],stocare2=c[start];
            for (int j=start;j>i;j--)
                {c[j]=c[j-1];P[j]=P[j-1];}
            c[i]=stocare2;
            P[i]=stocare1;
            i--;

           /*cout<<"b[i]:"<<endl;
            for (int i=1;i<=N;i++)
                cout<<P[i]<<" ";
            cout<<endl<<"c[i]:"<<endl;
            for (int i=1;i<=N;i++)
                cout<<c[i]<<" ";
            cout<<endl<<endl<<endl;*/

        }

    }

    return 0;
}

