#include <iostream>

using namespace std;

int main()
{   int P,T,N;
    cin>>P>>T;
    if (P==1)
    {
        int l=0,b[T];
        for (int h=1;h<=T;h++)
        {
            int N;
            cin>>N;
            int A[N][N];
            for (int i=1;i<=N;i++)
            {
                int cod;
                cin>>cod;
                for (int j=N;j>=1;j--)
                    {
                        A[i][j]=cod%10;
                        cod/=10;
                    }
            }
            bool ok=true;
            int q=0;
            for (int i=1;i<=N;i++)
                for (int j=1;j<=N;j++)
                    if (A[i][j]==1)
                        q++;
            if (q!=N*N/2)
                ok=false;


            if (ok==true)
                {l++;b[l]=1;}
            else
                {l++;b[l]=0;}

        }

        for (int i=1;i<=l;i++)
            cout<<b[i]<<endl;

    }


    return 0;
}
