#include <iostream>
#include <graphics.h>
#include <fstream>
#include <conio.h>
#include <queue>
#include <stdlib.h>
#include <time.h>

using namespace std;
ifstream f("Field.in");
queue<pair<int,int> >que;
int options=115;
bool ok=false,Insane=false;
int Matrice_Sarpe[22][22],Matrice_Hrana_Sarpe[22][22],Viteza_Sarpe;

void Snake()
{   int s=1,Score=0;
    system("pause");
    while(s)
    {   if (_kbhit())
        {   options=_getch();
            if (options==115) //s
            {   Matrice_Sarpe[que.front().first][que.front().second]=0;
                if (Matrice_Sarpe[que.back().first+1][que.back().second]==42)
                {   if (Matrice_Hrana_Sarpe[que.back().first+1][que.back().second]==42)
                    {   que.push({que.back().first+1,que.back().second});
                        Matrice_Hrana_Sarpe[que.back().first][que.back().second]=0;
                        ok=true;
                        Score++;
                    }
                    else
                        s=0;
                }
                else
                {   Matrice_Sarpe[que.back().first+1][que.back().second]=42;
                    que.push({que.back().first+1,que.back().second});
                    que.pop();
                }
            }
            if (options==119) //w
            {   Matrice_Sarpe[que.front().first][que.front().second]=0;
                if (Matrice_Sarpe[que.back().first-1][que.back().second]==42)
                {   if (Matrice_Hrana_Sarpe[que.back().first-1][que.back().second]==42)
                    {   que.push({que.back().first-1,que.back().second});
                        Matrice_Hrana_Sarpe[que.back().first][que.back().second]=0;
                        ok=true;
                        Score++;
                    }
                    else
                        s=0;
                }
                else
                {   Matrice_Sarpe[que.back().first-1][que.back().second]=42;
                    que.push({que.back().first-1,que.back().second});
                    que.pop();
                }
            }
            if (options==100) //d
            {   Matrice_Sarpe[que.front().first][que.front().second]=0;
                if (Matrice_Sarpe[que.back().first][que.back().second+1]==42)
                {   if (Matrice_Hrana_Sarpe[que.back().first][que.back().second+1]==42)
                    {   que.push({que.back().first,que.back().second+1});
                        Matrice_Hrana_Sarpe[que.back().first][que.back().second]=0;
                        ok=true;
                        Score++;
                    }
                    else
                        s=0;
                }
                else
                {   Matrice_Sarpe[que.back().first][que.back().second+1]=42;
                    que.push({que.back().first,que.back().second+1});
                    que.pop();
                }
            }
            if (options==97) //a
            {   Matrice_Sarpe[que.front().first][que.front().second]=0;
                if (Matrice_Sarpe[que.back().first][que.back().second-1]==42)
                {   if (Matrice_Hrana_Sarpe[que.back().first][que.back().second-1]==42)
                    {   que.push({que.back().first,que.back().second-1});
                        Matrice_Hrana_Sarpe[que.back().first][que.back().second]=0;
                        ok=true;
                        Score++;
                    }
                    else
                        s=0;
                }
                else
                {   Matrice_Sarpe[que.back().first][que.back().second-1]=42;
                    que.push({que.back().first,que.back().second-1});
                    que.pop();
                }
            }

        }

        else
        {   if (options==115&&_kbhit()==0) //s
            {   Matrice_Sarpe[que.front().first][que.front().second]=0;
                if (Matrice_Sarpe[que.back().first+1][que.back().second]==42)
                {   que.push({que.back().first+1,que.back().second});
                    Matrice_Hrana_Sarpe[que.back().first][que.back().second]=0;
                    ok=true;
                    Score++;
                }
                else
                {   Matrice_Sarpe[que.back().first+1][que.back().second]=42;
                    que.push({que.back().first+1,que.back().second});
                    que.pop();
                }
            }
            if (options==119&&_kbhit()==0) //w
            {   Matrice_Sarpe[que.front().first][que.front().second]=0;
                if (Matrice_Sarpe[que.back().first-1][que.back().second]==42)
                {   que.push({que.back().first-1,que.back().second});
                    Matrice_Hrana_Sarpe[que.back().first][que.back().second]=0;
                    ok=true;
                    Score++;
                }

                else
                {   Matrice_Sarpe[que.back().first-1][que.back().second]=42;
                    que.push({que.back().first-1,que.back().second});
                    que.pop();
                }
            }
            if (options==100&&_kbhit()==0) //d
            {   Matrice_Sarpe[que.front().first][que.front().second]=0;
                if (Matrice_Sarpe[que.back().first][que.back().second+1]==42)
                {   que.push({que.back().first,que.back().second+1});
                    Matrice_Hrana_Sarpe[que.back().first][que.back().second]=0;
                    ok=true;
                    Score++;
                }
                else
                {   Matrice_Sarpe[que.back().first][que.back().second+1]=42;
                    que.push({que.back().first,que.back().second+1});
                    que.pop();
                }
            }
            if (options==97&&_kbhit()==0) //a
            {   Matrice_Sarpe[que.front().first][que.front().second]=0;
                if (Matrice_Sarpe[que.back().first][que.back().second-1]==42)
                {   que.push({que.back().first,que.back().second-1});
                    Matrice_Hrana_Sarpe[que.back().first][que.back().second]=0;
                    ok=true;
                    Score++;
                }
                else
                {   Matrice_Sarpe[que.back().first][que.back().second-1]=42;
                    que.push({que.back().first,que.back().second-1});
                    que.pop();
                }
            }

        }
        if (que.back().first>21||que.back().first<1||que.back().second>21||que.back().second<1)
            s=0;



        /*for (int k=0;k<=22;k++)
        {   for (int l=0;l<=22;l++)
                cout<<char(b[k][l]);
            cout<<endl;
        }*/

        if (ok==true)
        {   ok=false;
            int i=rand()%21+1;
            int j=rand()%21+1;
            Matrice_Hrana_Sarpe[i][j]=42;
            Matrice_Sarpe[i][j]=42;
            if (Insane==true)
            {   i=rand()%21+1;
                j=rand()%21+1;
                Matrice_Hrana_Sarpe[i][j]=42;
                Matrice_Sarpe[i][j]=42;
                i=rand()%21+1;
                j=rand()%21+1;
                Matrice_Hrana_Sarpe[i][j]=42;
                Matrice_Sarpe[i][j]=42;
            }
        }

        if (s==1)
        {   for (int i=0;i<=22;i++)
            {    for (int j=0;j<=22;j++)
                    cout<<char(Matrice_Sarpe[i][j]);
                cout<<endl;
            }
            Sleep(Viteza_Sarpe);
        }
        system("cls");
    }
    system("cls");
    cout<<"Game over!"<<endl<<"Score: "<<Score;
}


int main()
{   for (int i=0;i<=22;i++)
        for (int j=0;j<=22;j++)
            f>>Matrice_Sarpe[i][j];
    for (int i=0;i<=22;i++)
    {Matrice_Sarpe[i][0]=35;Matrice_Sarpe[i][22]=35;Matrice_Sarpe[0][i]=35;Matrice_Sarpe[22][i]=35;}
    for (int i=0;i<=22;i++)
    {Matrice_Hrana_Sarpe[i][0]=35;Matrice_Hrana_Sarpe[i][22]=35;Matrice_Hrana_Sarpe[0][i]=35;Matrice_Hrana_Sarpe[22][i]=35;}

    /*for (int k=1;k<=3;k++)
    {   cin>>i>>j;
        Matrice_Sarpe[i][j]=42;
        que.push(i,j);
    }*/
    int i,j;
    i=5,j=6;
    Matrice_Sarpe[i][j]=42;
    que.push({i,j});
    i=6;j=6;
    Matrice_Sarpe[i][j]=42;
    que.push({i,j});
    i=6;j=7;
    Matrice_Sarpe[i][j]=42;
    que.push({i,j});

    srand(time(NULL));
    i=rand()%21+1;
    j=rand()%21+1;
    Matrice_Sarpe[i][j]=42;
    Matrice_Hrana_Sarpe[i][j]=42;
    int optiune_dificultate;
    cout<<"Difficulty:"<<endl;
    cout<<"1)Easy"<<endl;
    cout<<"2)Medium"<<endl;
    cout<<"3)Hard"<<endl;
    cout<<"4)Insane";
    optiune_dificultate=_getch()-48;
    system("cls");
    if (optiune_dificultate==1)
        Viteza_Sarpe=600;
    else
        if (optiune_dificultate==2)
            Viteza_Sarpe=300;
        else
            if (optiune_dificultate==3)
                Viteza_Sarpe=150;
            else
                {Viteza_Sarpe=80;Insane=true;}

    Snake();

    return 0;
}
