package org.Alex.medicul;

import java.awt.*;

public class RightEye extends Organs{

    public RightEye(String name, String medicalCondition) {
        super(name, medicalCondition);
    }

    public void closeRightEye () {
        System.out.println("Right eye closed");
    }

    String color = "Purple";

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

}
