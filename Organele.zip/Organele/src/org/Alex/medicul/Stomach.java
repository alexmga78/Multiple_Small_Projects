package org.Alex.medicul;

public class Stomach extends Organs {

    public Stomach(String name, String medicalCondition) {
        super(name, medicalCondition);
    }

    public void digest () {
        System.out.println ("Digesting begins. . .");
    }

}
