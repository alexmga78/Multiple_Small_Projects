package org.Alex.medicul;

import java.util.Scanner;

public class Heart extends Organs{

    public Heart(String name, String medicalCondition) {
        super(name, medicalCondition);
    }

    Scanner scanner = new Scanner (System.in);

    public void changeHeartRate () {
        System.out.println ("Enter the new heart rate");
        setHeartRate (scanner.nextInt());
        System.out.println ("Heart rate changed to: " + getHeartRate());
    }

    int heartRate = 65;

    public int getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(int heartRate) {
        this.heartRate = heartRate;
    }

}
