package org.Alex.medicul;

public class LeftEye extends Organs {

    public LeftEye(String name, String medicalCondition) {
        super(name, medicalCondition);
    }


    public void closeLeftEye () {
        System.out.println("Left eye closed");
    }

    String color = "Purple";

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
