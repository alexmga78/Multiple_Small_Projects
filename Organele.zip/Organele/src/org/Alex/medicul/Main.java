package org.Alex.medicul;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Person Tom = new Person ("Tom", 25);

        LeftEye leftEye = new LeftEye ("Left Eye", "Normal");

        RightEye rightEye = new RightEye ("Right Eye", "Short Sighted");

        Heart heart = new Heart ("Heart", "Normal");

        Stomach stomach = new Stomach ("Stomach", "PUD");

        Skin skin = new Skin ("Skin", "Burned");


        System.out.println ("Name: " + Tom.getName());
        System.out.println ("Age: " + Tom.getAge());

        Scanner scanner = new Scanner (System.in);
        int choice = 0;

        while (choice != 6){
            System.out.println ("Choice an organ:");
            System.out.println ("\t1) Left eye");
            System.out.println ("\t2) Right eye");
            System.out.println ("\t3)Heart");
            System.out.println ("\t4)Stomach");
            System.out.println ("\t5)Skin");
            System.out.println ("\t6)Quit");

            choice = scanner.nextInt();

            if (choice == 1){
                System.out.println ("Name: " + leftEye.getName());
                System.out.println ("Medical condition: " + leftEye.getMedicalCondition());
                System.out.println ("Color: " + leftEye.getColor());
                System.out.println ("\t1)Close the eye");

                choice = scanner.nextInt();

                if (choice == 1) {
                    leftEye.closeLeftEye();
                }
            }else if (choice == 2){
                    System.out.println ("Name: " + rightEye.getName());
                    System.out.println ("Medical condition: " + rightEye.getMedicalCondition());
                    System.out.println ("Color: " + rightEye.getColor());
                    System.out.println ("\t1)Close the eye");

                    choice = scanner.nextInt();

                    if (choice == 1){
                        rightEye.closeRightEye();
                    }
            }else if (choice == 3){
                    System.out.println ("Name: " + heart.getName());
                    System.out.println ("Medical condition: " + heart.getMedicalCondition());
                    System.out.println ("Heart rate: " + heart.getHeartRate());
                    System.out.println ("\t1)Change heart rate");

                    choice = scanner.nextInt();

                    if (choice == 1){
                        heart.changeHeartRate();
                    }
            }else if (choice == 4){
                System.out.println ("Name: " + stomach.getName());
                System.out.println ("Medical condition: " + stomach.getMedicalCondition());
                System.out.println ("Need to be fed");
                System.out.println ("\t1)Digest");

                choice = scanner.nextInt();

                if (choice == 1){
                    stomach.digest();
                }
            }else if (choice == 5){
                System.out.println ("Name: " + skin.getName());
                System.out.println ("Medical condition: " + skin.getMedicalCondition());

            }else if (choice == 6){
                break;
            }

            choice = 0;

        }



    }
}
