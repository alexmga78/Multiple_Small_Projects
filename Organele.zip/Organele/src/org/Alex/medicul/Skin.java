package org.Alex.medicul;

public class Skin extends Organs{

    public Skin(String name, String medicalCondition) {
        super(name, medicalCondition);
    }

}
