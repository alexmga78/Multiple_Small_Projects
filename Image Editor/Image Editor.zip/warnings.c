#include "image_editor.h"

int black_and_white_image(uint focus) {
  if (focus != 2) {
    printf("Black and white image needed\n");
    return -1;
  }
  return 1;
}

int no_image_loaded(pbm pbm_img, pgm pgm_img, ppm ppm_img, uint focus) {
  if (focus == 0 || (focus == 1 && !pbm_img.loaded) ||
      (focus == 2 && !pgm_img.loaded) || (focus == 3 && !ppm_img.loaded)) {
    printf("No image loaded\n");
    return -1;
  }

  return 1;
}
