#include "image_editor.h"

//  Verify if the read text is a command
static int verify_if_command(char command_aux[20]) {
  if (!strcmp(command_aux, "LOAD") || !strcmp(command_aux, "SELECT") ||
      !strcmp(command_aux, "HISTOGRAM") || !strcmp(command_aux, "EQUALIZE") ||
      !strcmp(command_aux, "ROTATE") || !strcmp(command_aux, "CROP") ||
      !strcmp(command_aux, "APPLY") || !strcmp(command_aux, "SAVE") ||
      !strcmp(command_aux, "EXIT"))
    return 1;

  return 0;
}

//  Reads y1, x2, y2 coordinates
static int read_coordinates(int *y1, int *x2, int *y2, char **command) {
  char command_aux[20];

  scanf("%s", command_aux);
  if (command_aux[0] != '-') {
    uint i = 0;
    while (command_aux[i]) {
      if ((command_aux[i] < 48 || command_aux[i] > 57) && command_aux[i] != 0) {
        if (verify_if_command(command_aux) == 1) {
          strcpy(*command, command_aux);

          printf("Invalid command\n");
          return 0;
        }

        printf("Invalid command\n");
        return -1;
      }
      *y1 = (*y1 * 10) + command_aux[i++] - 48;
    }
  } else {
    int aux;
    scanf(" %d %d", &aux, &aux);

    printf("Invalid set of coordinates\n");
    return -1;
  }

  scanf("%s", command_aux);
  if (command_aux[0] != '-') {
    uint i = 0;
    while (command_aux[i]) {
      if ((command_aux[i] < 48 || command_aux[i] > 57) && command_aux[i] != 0) {
        if (verify_if_command(command_aux) == 1) {
          strcpy(*command, command_aux);

          printf("Invalid command\n");
          return 0;
        }

        printf("Invalid command\n");
        return -1;
      }
      *x2 = (*x2 * 10) + command_aux[i++] - 48;
    }
  } else {
    int aux;
    scanf(" %d", &aux);
    printf("Invalid set of coordinates\n");
    return -1;
  }

  scanf("%s", command_aux);
  if (command_aux[0] != '-') {
    uint i = 0;
    while (command_aux[i]) {
      if ((command_aux[i] < 48 || command_aux[i] > 57) && command_aux[i] != 0) {
        if (verify_if_command(command_aux) == 1) {
          strcpy(*command, command_aux);

          printf("Invalid command\n");
          return 0;
        }

        printf("Invalid command\n");
        return -1;
      }
      *y2 = (*y2 * 10) + command_aux[i++] - 48;
    }
  } else {
    printf("Invalid set of coordinates\n");
    return -1;
  }

  return 1;
}

//  Opens the file in read mode (defensive)
static int open_file_read(char *filename, FILE **image) {
  *image = fopen(filename, "r");

  if (!*image) {
    fprintf(stdout, "Failed to load %s\n", filename);
    free(filename);
    return -1;
  }

  return 1;
}

//  Opens the file in write mode (defensive)
static int open_file_write(char *filename, FILE **image) {
  *image = fopen(filename, "w");

  if (!*image) {
    fprintf(stdout, "Failed to load %s\n", filename);
    free(filename);
    return -1;
  }

  return 1;
}

//  Initializes with 0 "loaded" object's variable (loaded keeps track if that
//  type of image has one allocated)
static void initialize_images(pbm *pbm_img, pgm *pgm_img, ppm *ppm_img) {
  (*pbm_img).loaded = 0;
  (*pgm_img).loaded = 0;
  (*ppm_img).loaded = 0;
}

//  Alloc memory for variable "command"
static int alloc_command(char **command, char **command_to_repeat) {
  *command = (char *)malloc(20 * sizeof(char));
  if (!*command) {
    fprintf(stderr, "Failed to alloc memory for 'command'\n");
    return -1;
  }

  *command_to_repeat = (char *)malloc(20 * sizeof(char));
  if (!*command_to_repeat) {
    fprintf(stderr, "Failed to alloc memory for 'command_to_repeat'\n");
    return -1;
  }

  return 1;
}

//  Frees pbm/pgm/ppm _img memory
static void free_images(pbm *pbm_img, pgm *pgm_img, ppm *ppm_img) {
  //  Frees pbm image memory if it has been loaded
  if ((*pbm_img).loaded) {
    for (uint i = (*pbm_img).height_start; i < (*pbm_img).height; i++)
      free((*pbm_img).matrix[i]);
    free((*pbm_img).matrix);
    (*pbm_img).loaded = 0;
  }

  //  Frees pgm image memory if it has been loaded
  if ((*pgm_img).loaded) {
    for (uint i = (*pgm_img).height_start; i < (*pgm_img).height; i++)
      free((*pgm_img).matrix[i]);
    free((*pgm_img).matrix);
    (*pgm_img).loaded = 0;
  }

  //  Frees ppm image memory if it has been loaded
  if ((*ppm_img).loaded) {
    for (uint k = (*ppm_img).width_start; k < (*ppm_img).width; k++) {
      for (uint i = (*ppm_img).height_start; i < (*ppm_img).height; i++)
        free(((*ppm_img).matrix)[k][i]);
      free((*ppm_img).matrix[k]);
    }
    free((*ppm_img).matrix);
    (*ppm_img).loaded = 0;
  }
}

//  Frees commands vectors
static void free_commands_and_exit(char **command, char **command_to_repeat) {
  free(*command);
  free(*command_to_repeat);
  exit(0);
}

//  Removes comments from the image file
static void remove_comments(FILE *image) {
  char verify_comment[1024];
  fscanf(image, " %s", verify_comment);
  if (verify_comment[0] == '#') {
    fseek(image, 0L, SEEK_SET);
    while (verify_comment[0] == '#') {
      fgets(verify_comment, 1024, image);
    }
  }
  fseek(image, -strlen(verify_comment), SEEK_CUR);
}

//  Get the type of command (transform the command in integer)
static int get_type(char *command) {
  if (!strcmp(command, "LOAD")) return 1;
  if (!strcmp(command, "SELECT")) return 2;
  if (!strcmp(command, "HISTOGRAM")) return 3;
  if (!strcmp(command, "EQUALIZE")) return 4;
  if (!strcmp(command, "ROTATE")) return 5;
  if (!strcmp(command, "CROP")) return 6;
  if (!strcmp(command, "APPLY")) return 7;
  if (!strcmp(command, "SAVE")) return 8;
  if (!strcmp(command, "EXIT")) return 9;

  if (!strcmp(command, "BLUR") || !strcmp(command, "EDGE") ||
      !strcmp(command, "GAUSSIAN_BLUR") || !strcmp(command, "SHARPEN"))
    return 99;

  return 0;
}

//  The switch for "load" routes
static int load_routes(pbm *pbm_img, pgm *pgm_img, ppm *ppm_img, uint *focus) {
  uint filename_max_letters = 30, type = 0;
  char *filename = (char *)malloc(filename_max_letters * sizeof(char));

  free_images(pbm_img, pgm_img, ppm_img);

  if (!filename) {
    fprintf(stderr, "Failed to alloc memory for 'filename'\n");
    exit(500);
  }
  scanf("%s", filename);

  FILE *image = NULL;
  if (open_file_read(filename, &image) == -1) return -1;

  char type_aux[2];
  remove_comments(image);
  fscanf(image, "%s", type_aux);
  type = type_aux[1] - 48;

  switch (type) {
    case 1:
      *focus = 1;
      pbm_loadText(&filename, &image, pbm_img);
      break;
    case 2:
      *focus = 2;
      pgm_loadText(&filename, &image, pgm_img);
      break;

    case 3:
      *focus = 3;
      ppm_loadText(&filename, &image, ppm_img);
      break;

    case 4:
      *focus = 1;
      pbm_loadBin(&filename, &image, pbm_img);
      break;

    case 5:
      *focus = 2;
      pgm_loadBin(&filename, &image, pgm_img);
      break;

    case 6:
      *focus = 3;
      ppm_loadBin(&filename, &image, ppm_img);
      break;

    default:
      break;
  }

  return 1;
}

//  The switch for "select" routes
static int select_routes(pbm *pbm_img, pgm *pgm_img, ppm *ppm_img, uint focus,
                         char **command) {
  char command_aux[20];

  scanf("%s", command_aux);

  if (!strcmp(command_aux, "ALL"))
    select_all(pbm_img, pgm_img, ppm_img, focus);
  else {
    int x1 = 0, y1 = 0, x2 = 0, y2 = 0;

    if (no_image_loaded(*pbm_img, *pgm_img, *ppm_img, focus) == -1) {
      int aux;
      scanf(" %d %d %d %d", &aux, &aux, &aux, &aux);
      return -1;
    }

    if (command_aux[0] != '-') {
      uint i = 0;
      while (command_aux[i]) {
        if ((command_aux[i] < 48 || command_aux[i] > 57) &&
            command_aux[i] != 0) {
          if (verify_if_command(command_aux) == 1) {
            strcpy(*command, command_aux);

            printf("Invalid command\n");
            return 0;
          }

          return -1;
        }
        x1 = (x1 * 10) + command_aux[i++] - 48;
      }
    } else {
      int aux;
      scanf(" %d %d %d", &aux, &aux, &aux);

      printf("Invalid set of coordinates\n");
      return -1;
    }

    int return_value = read_coordinates(&y1, &x2, &y2, command);

    if (return_value != 1) return return_value;

    select(pbm_img, pgm_img, ppm_img, focus, x1, y1, x2, y2);
  }

  return 1;
}

//  The switch for "histrogam" routes
static int histogram_routes(pbm pbm_img, pgm pgm_img, ppm ppm_img, uint focus,
                            char **command) {
  char command_aux[20];
  uint stars_max = 0;

  scanf(" %s", command_aux);

  uint i = 0;
  while (command_aux[i]) {
    if ((command_aux[i] < 48 || command_aux[i] > 57) && command_aux[i] != 0) {
      if (verify_if_command(command_aux) == 1) {
        strcpy(*command, command_aux);

        printf("Invalid command\n");
        return 0;
      }

      return -1;
    }
    stars_max = (stars_max * 10) + command_aux[i++] - 48;
  }

  //  Verifies if there is any image loaded
  if (no_image_loaded(pbm_img, pgm_img, ppm_img, focus) == -1) {
    uint aux;
    scanf(" %d", &aux);
    return -1;
  }

  //  Verifies if the loaded image is black&white (pgm)
  if (black_and_white_image(focus) == -1) {
    uint aux;
    scanf(" %d", &aux);
    return -1;
  }

  histogram(pgm_img, stars_max);

  return 1;
}

//  The switch for "equalize" routes
static int equalize_routes(pbm pbm_img, pgm *pgm_img, ppm ppm_img, uint focus) {
  //  Verifies if there is any image loaded
  if (no_image_loaded(pbm_img, *pgm_img, ppm_img, focus) == -1) return -1;

  //  Verifies if the loaded image is black&white (pgm)
  if (black_and_white_image(focus) == -1) return -1;

  equalize(pgm_img);

  return 1;
}

//  The switch for "apply" routes
static int apply_routes(pbm pbm_img, pgm *pgm_img, ppm *ppm_img, uint focus,
                        char **command) {
  if (no_image_loaded(pbm_img, *pgm_img, *ppm_img, focus) == -1) return -1;

  char parameter[20];
  scanf(" %s", parameter);

  if (verify_if_command(parameter) == 1) {
    strcpy(*command, parameter);
    printf("Invalid command\n");

    return 0;
  }

  if (!strcmp(parameter, "BLUR")) {
    apply_blur(pgm_img, ppm_img, focus);
  } else if (!strcmp(parameter, "EDGE")) {
    apply_edge(pgm_img, ppm_img, focus);
  } else if (!strcmp(parameter, "GAUSSIAN_BLUR")) {
    apply_gaussian_blur(pgm_img, ppm_img, focus);
  } else if (!strcmp(parameter, "SHARPEN")) {
    apply_sharpen(pgm_img, ppm_img, focus);
  } else {
    printf("APPLY parameter invalid\n");
  }

  return 1;
}

//  The switch for "save" routes
static int save_routes(pbm pbm_img, pgm pgm_img, ppm ppm_img, uint focus) {
  char parameters[50] = {0};
  uint filename_max_letters = 30, ascii = 0;

  //  Verifies if there is any image loaded
  if (no_image_loaded(pbm_img, pgm_img, ppm_img, focus) == -1) {
    char aux[50];
    scanf(" %s", aux);
    return -1;
  }

  //  Reads filename
  char *filename = (char *)malloc(filename_max_letters * sizeof(char));
  if (!filename) {
    fprintf(stderr, "Failed to alloc memory for 'filename'\n");
    free_images(&pbm_img, &pgm_img, &ppm_img);
    exit(500);
  }
  scanf("%s", filename);

  //  Opens the file in write mode
  FILE *image = NULL;
  if (open_file_write(filename, &image) == -1) return -1;

  //  Identifies if "ascii" attribute is true
  fgets(parameters, 20, stdin);
  parameters[strlen(parameters)] = 0;
  if (parameters[1] == 'a' && parameters[2] == 's' && parameters[3] == 'c' &&
      parameters[4] == 'i' && parameters[5] == 'i' && parameters[6] == '\n')
    ascii = 1;

  switch (ascii) {
    case 0:
      save_bin(&filename, &image, pbm_img, pgm_img, ppm_img, focus);
      break;

    case 1:
      save_text(&filename, &image, pbm_img, pgm_img, ppm_img, focus);
      break;

    default:
      break;
  }

  return 1;
}

int main(void) {
  pbm pbm_img;
  pgm pgm_img;
  ppm ppm_img;
  uint focus = 0, exit_count = 0, repeat_command = 0;
  char *command, *command_to_repeat;

  if (alloc_command(&command, &command_to_repeat) == -1) exit(500);

  initialize_images(&pbm_img, &pgm_img, &ppm_img);

  while (1) {
    if (repeat_command == 0)
      scanf("%s", command);
    else {
      for (uint i = 0; i < strlen(command_to_repeat); i++)
        command[i] = command_to_repeat[i];
      for (uint i = strlen(command_to_repeat); i < strlen(command); i++)
        command[i] = 0;
      repeat_command = 0;
    }

    if (!strcmp(command, "ascii") || !strcmp(command, "FAULT")) continue;

    switch (get_type(command)) {
      case 1:
        load_routes(&pbm_img, &pgm_img, &ppm_img, &focus);
        exit_count = 0;
        break;

      case 2:
        if (select_routes(&pbm_img, &pgm_img, &ppm_img, focus, &command) == 0) {
          repeat_command = 1;
          strcpy(command_to_repeat, command);
        }
        exit_count = 0;
        break;

      case 3:
        if (histogram_routes(pbm_img, pgm_img, ppm_img, focus, &command) == 0) {
          repeat_command = 1;
          strcpy(command_to_repeat, command);
        }
        exit_count = 0;
        break;

      case 4:
        equalize_routes(pbm_img, &pgm_img, ppm_img, focus);
        exit_count = 0;
        break;

      case 5:
        rotate(&pbm_img, &pgm_img, &ppm_img, focus);
        exit_count = 0;
        break;

      case 6:
        crop(&pbm_img, &pgm_img, &ppm_img, focus);
        exit_count = 0;
        break;

      case 7:
        if (apply_routes(pbm_img, &pgm_img, &ppm_img, focus, &command) == 0) {
          repeat_command = 1;
          strcpy(command_to_repeat, command);
        }
        exit_count = 0;
        break;

      case 8:
        save_routes(pbm_img, pgm_img, ppm_img, focus);
        exit_count = 0;
        break;

      case 9:
        if (exit_count) {
          free_images(&pbm_img, &pgm_img, &ppm_img);
          free_commands_and_exit(&command, &command_to_repeat);
        } else if (no_image_loaded(pbm_img, pgm_img, ppm_img, focus) == 1) {
          free_images(&pbm_img, &pgm_img, &ppm_img);
          free_commands_and_exit(&command, &command_to_repeat);
        } else
          exit_count++;
        break;

      case 99:
        break;

      default:
        printf("Invalid command\n");
        break;
    }
  }

  return 0;
}
