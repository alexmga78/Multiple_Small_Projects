#ifndef __image_editor_h__
#define __image_editor_h__

#define uint unsigned int
#define ull unsigned long long
#define uch unsigned char

#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//  .pbm image
typedef struct pbm {
  uint x1, x2, y1, y2;
  uint loaded;
  uint width_start;
  uint height_start;
  uint width;
  uint height;
  uch **matrix;
} pbm;

//  .pgm image
typedef struct pgm {
  uint x1, x2, y1, y2;
  uint loaded;
  uint width_start;
  uint height_start;
  uint width;
  uint height;
  ull max_intensity;
  uch **matrix;
} pgm;

//  .ppm image
typedef struct ppm {
  uint x1, x2, y1, y2;
  uint loaded;
  uint width_start;
  uint height_start;
  uint width;
  uint height;
  ull max_intensity;
  uch ***matrix;
} ppm;

//  FILE: apply.c
//  Redirect what image type to blur
int apply_blur(pgm *pgm_img, ppm *ppm_img, uint focus);
//  Redirect what image type to edge
int apply_edge(pgm *pgm_img, ppm *ppm_img, uint focus);
//  Redirect what image type to gaussian blur
int apply_gaussian_blur(pgm *pgm_img, ppm *ppm_img, uint focus);
//  Redirect what image type to sharpen
int apply_sharpen(pgm *pgm_img, ppm *ppm_img, uint focus);

//  FILE: crop.c
//  redim. an image with a lower size (crop)
int crop(pbm *pbm_img, pgm *pgm_img, ppm *ppm_img, uint focus);

//  FILE: equalize.c
//  Equalizes a pgm image
int equalize(pgm *pgm_img);

//  FILE: histrogram.c
//  Prints the histogram of a Grayscale image
int histogram(pgm pgm_img, uint stars_max);

//  FILE: load.c
//  Route load (pbm-text format)
int pbm_loadText(char **filename, FILE **image, pbm *pbm_img);
//  Route load (pgm-text format)
int pgm_loadText(char **filename, FILE **image, pgm *pgm_img);
//  Route load (ppm-text format)
int ppm_loadText(char **filename, FILE **image, ppm *ppm_img);
//  Route load (pbm-binary format)
int pbm_loadBin(char **filename, FILE **image, pbm *pbm_img);
//  Route load (pgm-binary format)
int pgm_loadBin(char **filename, FILE **image, pgm *pgm_img);
//  Route load (ppm-binary format)
int ppm_loadBin(char **filename, FILE **image, ppm *ppm_img);

//  FILE: rotate.c
//  The switch for "rotate" routes
int rotate(pbm *pbm_img, pgm *pgm_img, ppm *ppm_img, uint focus);

//  FILE: save.c
//  Route save (binary format)
int save_bin(char **filename, FILE **image, pbm pbm_img, pgm pgm_img,
             ppm ppm_img, uint focus);
//  Route save (text format)
int save_text(char **filename, FILE **image, pbm pbm_img, pgm pgm_img,
              ppm ppm_img, uint focus);

//  FILE: select_all.c
//  The switch for "select_all" routes
int select_all(pbm *pbm_img, pgm *pgm_img, ppm *ppm_img, uint focus);

//  FILE: select.c
//  The switch for "select" routes
int select(pbm *pbm_img, pgm *pgm_img, ppm *ppm_img, uint focus, int x1, int y1,
           int x2, int y2);

//  FILE: utils.c
//  Alloc new_matrix (pbm type)
int alloc_new_matrix_pbm(pbm pbm_img, uch ***new_matrix);
//  Alloc new_matrix (pgm type)
int alloc_new_matrix_pgm(pgm pgm_img, uch ***new_matrix);
//  Alloc new_matrix (ppm type)
int alloc_new_matrix_ppm(ppm ppm_img, uch ****new_matrix);
//  Copy the new_matrix into the original image (pbm type)
void copy_new_matrix_to_image_pbm(pbm *pbm_img, uch **new_matrix,
                                  uint apply_start_i, uint apply_start_j,
                                  uint apply_fin_i, uint apply_fin_j);
//  Copy the new_matrix into the original image (pgm type)
void copy_new_matrix_to_image_pgm(pgm *pgm_img, uch **new_matrix,
                                  uint apply_start_i, uint apply_start_j,
                                  uint apply_fin_i, uint apply_fin_j);
//  Copy the new_matrix into the original image (ppm type)
void copy_new_matrix_to_image_ppm(ppm *ppm_img, uch ***new_matrix,
                                  uint apply_start_i, uint apply_start_j,
                                  uint apply_fin_i, uint apply_fin_j);
//  Free the auxiliary matrix (pbm type)
void free_new_matrix_pbm(pbm pbm_img, uch ***new_matrix);
//  Free the auxiliary matrix (pgm type)
void free_new_matrix_pgm(pgm pgm_img, uch ***new_matrix);
//  Free the auxiliary matrix (ppm type)
void free_new_matrix_ppm(ppm ppm_img, uch ****new_matrix);
//  Swaps 2 int numbers
void swap(int *number1, int *number2);
//  Swaps 2 unsigned int numbers
void swap_uint(uint *number1, uint *number2);

//  FILE: warnings.c
//  Verify if the given image is not black and white
int black_and_white_image(uint focus);
//  Verify if there isn't any image uploaded
int no_image_loaded(pbm pbm_img, pgm pgm_img, ppm ppm_img, uint focus);

#endif