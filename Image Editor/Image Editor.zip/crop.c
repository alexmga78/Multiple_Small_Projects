#include "image_editor.h"

//  Crop image (pbm)
static void pbm_crop(pbm *pbm_img) {
  uch **new_matrix;
  uint height = (*pbm_img).y2 - (*pbm_img).y1,
       width = (*pbm_img).x2 - (*pbm_img).x1;

  alloc_new_matrix_pbm(*pbm_img, &new_matrix);

  for (uint i = 0; i < height; i++)
    for (uint j = 0; j < width; j++)
      new_matrix[i][j] =
          (*pbm_img).matrix[i + (*pbm_img).y1][j + (*pbm_img).x1];

  copy_new_matrix_to_image_pbm(pbm_img, new_matrix, 0, 0, height, width);

  free_new_matrix_pbm(*pbm_img, &new_matrix);
  //  Frees pbm image memory that is being cropped out
  for (uint i = height; i < (*pbm_img).height; i++) free((*pbm_img).matrix[i]);

  //  Asign the new "hard" dimensions
  (*pbm_img).width_start = 0;
  (*pbm_img).height_start = 0;
  (*pbm_img).width = width;
  (*pbm_img).height = height;
  (*pbm_img).x1 = 0;
  (*pbm_img).y1 = 0;
  (*pbm_img).x2 = width;
  (*pbm_img).y2 = height;
}

//  Crop image (pgm)
static void pgm_crop(pgm *pgm_img) {
  uch **new_matrix;
  uint height = (*pgm_img).y2 - (*pgm_img).y1,
       width = (*pgm_img).x2 - (*pgm_img).x1;

  alloc_new_matrix_pgm(*pgm_img, &new_matrix);

  for (uint i = 0; i < height; i++)
    for (uint j = 0; j < width; j++)
      new_matrix[i][j] =
          (*pgm_img).matrix[i + (*pgm_img).y1][j + (*pgm_img).x1];

  copy_new_matrix_to_image_pgm(pgm_img, new_matrix, 0, 0, height, width);

  free_new_matrix_pgm(*pgm_img, &new_matrix);
  //  Frees pgm image memory that is being cropped out
  for (uint i = height; i < (*pgm_img).height; i++) free((*pgm_img).matrix[i]);

  //  Asign the new "hard" dimensions
  (*pgm_img).width_start = 0;
  (*pgm_img).height_start = 0;
  (*pgm_img).width = width;
  (*pgm_img).height = height;
  (*pgm_img).x1 = 0;
  (*pgm_img).y1 = 0;
  (*pgm_img).x2 = width;
  (*pgm_img).y2 = height;
}

//  Crop image (ppm)
static void ppm_crop(ppm *ppm_img) {
  uch ***new_matrix;
  uint height = (*ppm_img).y2 - (*ppm_img).y1,
       width = (*ppm_img).x2 - (*ppm_img).x1, rgb = 3;

  alloc_new_matrix_ppm(*ppm_img, &new_matrix);

  //  Copy the selected part from original image to new_matrix
  for (uint i = 0; i < height; i++)
    for (uint k = 0; k < width; k++)
      for (uint j = 0; j < rgb; j++)
        new_matrix[i][k][j] =
            (*ppm_img).matrix[k + (*ppm_img).x1][i + (*ppm_img).y1][j];

  copy_new_matrix_to_image_ppm(ppm_img, new_matrix, 0, 0, height, width);

  free_new_matrix_ppm(*ppm_img, &new_matrix);
  //  Frees ppm image memory that is being cropped out
  for (uint k = width; k < (*ppm_img).width; k++) {
    for (uint i = 0; i < (*ppm_img).height; i++) free((*ppm_img).matrix[k][i]);
    free((*ppm_img).matrix[k]);
  }
  for (uint k = 0; k < width; k++)
    for (uint i = height; i < (*ppm_img).height; i++)
      free((*ppm_img).matrix[k][i]);

  //  Asign the new "hard" dimensions
  (*ppm_img).width_start = 0;
  (*ppm_img).height_start = 0;
  (*ppm_img).width = width;
  (*ppm_img).height = height;
  (*ppm_img).x1 = 0;
  (*ppm_img).y1 = 0;
  (*ppm_img).x2 = width;
  (*ppm_img).y2 = height;
}

int crop(pbm *pbm_img, pgm *pgm_img, ppm *ppm_img, uint focus) {
  if (no_image_loaded(*pbm_img, *pgm_img, *ppm_img, focus) == -1) return -1;

  switch (focus) {
    case 1:
      pbm_crop(pbm_img);
      break;

    case 2:
      pgm_crop(pgm_img);
      break;

    case 3:
      ppm_crop(ppm_img);
      break;

    default:
      printf("\"Focus is invalid\"\n");
      break;
  }

  printf("Image cropped\n");
  return 1;
}
