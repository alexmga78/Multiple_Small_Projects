#include "image_editor.h"

int alloc_new_matrix_pbm(pbm pbm_img, uch ***new_matrix) {
  //  Alloc lines
  *new_matrix = (uch **)malloc(pbm_img.height * sizeof(uch *));
  if (!*new_matrix) {
    fprintf(stderr, "Failed to alloc memory for 'new_matrix'\n");
    return -1;
  }

  //  Alloc cols
  for (uint i = pbm_img.height_start; i < pbm_img.height; i++) {
    new_matrix[0][i] = (uch *)malloc(pbm_img.width * sizeof(uch));
    if (!new_matrix[0][i]) {
      fprintf(stderr, "Failed to alloc memory for 'new_matrix[%d]'\n", i);
      while (i > 0) free(new_matrix[0][--i]);
      free(*new_matrix);
      return -1;
    }
  }
  return 1;
}

int alloc_new_matrix_pgm(pgm pgm_img, uch ***new_matrix) {
  //  Alloc lines
  *new_matrix = (uch **)malloc(pgm_img.height * sizeof(uch *));
  if (!*new_matrix) {
    fprintf(stderr, "Failed to alloc memory for 'new_matrix'\n");
    return -1;
  }

  //  Alloc cols
  for (uint i = pgm_img.height_start; i < pgm_img.height; i++) {
    new_matrix[0][i] = (uch *)malloc(pgm_img.width * sizeof(uch));
    if (!new_matrix[0][i]) {
      fprintf(stderr, "Failed to alloc memory for 'new_matrix[%d]'\n", i);
      while (i > 0) free(new_matrix[0][--i]);
      free(*new_matrix);
      return -1;
    }
  }
  return 1;
}

int alloc_new_matrix_ppm(ppm ppm_img, uch ****new_matrix) {
  uint rgb = 3;

  //  Alloc lines
  *new_matrix = (uch ***)malloc(ppm_img.height * sizeof(uch **));
  if (!*new_matrix) {
    fprintf(stderr, "Failed to alloc memory for 'new_matrix'\n");
    return -1;
  }

  //  Alloc cols
  for (uint i = ppm_img.height_start; i < ppm_img.height; i++) {
    new_matrix[0][i] = (uch **)malloc(ppm_img.width * sizeof(uch *));
    if (!new_matrix[0][i]) {
      fprintf(stderr, "Failed to alloc memory for 'new_matrix[%d]'\n", i);
      while (i > 0) free(new_matrix[0][--i]);
      free(*new_matrix);
      return -1;
    }
  }

  //  Alloc rgb
  for (uint i = ppm_img.height_start; i < ppm_img.height; i++)
    for (uint j = ppm_img.width_start; j < ppm_img.width; j++) {
      new_matrix[0][i][j] = (uch *)malloc(rgb * sizeof(uch));
      if (!new_matrix[0][i][j]) {
        fprintf(stderr, "Failed to alloc memory for 'new_matrix[%d][%d]'\n", i,
                j);
        while (j > 0) free(new_matrix[0][i][--j]);
        free(new_matrix[0][i]);
        for (uint l = i; l > 0; --l) {
          for (uint m = ppm_img.height_start; m < ppm_img.height; m++)
            free(new_matrix[0][l][m]);
          free(new_matrix[0][l]);
        }
        free(*new_matrix);
        return -1;
      }
    }

  return 1;
}

void copy_new_matrix_to_image_pbm(pbm *pbm_img, uch **new_matrix,
                                  uint apply_start_i, uint apply_start_j,
                                  uint apply_fin_i, uint apply_fin_j) {
  for (uint i = apply_start_i; i < apply_fin_i; i++)
    for (uint j = apply_start_j; j < apply_fin_j; j++)
      (*pbm_img).matrix[i][j] = new_matrix[i][j];
}

void copy_new_matrix_to_image_pgm(pgm *pgm_img, uch **new_matrix,
                                  uint apply_start_i, uint apply_start_j,
                                  uint apply_fin_i, uint apply_fin_j) {
  for (uint i = apply_start_i; i < apply_fin_i; i++)
    for (uint j = apply_start_j; j < apply_fin_j; j++)
      (*pgm_img).matrix[i][j] = new_matrix[i][j];
}

void copy_new_matrix_to_image_ppm(ppm *ppm_img, uch ***new_matrix,
                                  uint apply_start_i, uint apply_start_j,
                                  uint apply_fin_i, uint apply_fin_j) {
  uint rgb = 3;

  for (uint i = apply_start_i; i < apply_fin_i; i++)
    for (uint k = apply_start_j; k < apply_fin_j; k++)
      for (uint j = 0; j < rgb; j++)
        (*ppm_img).matrix[k][i][j] = new_matrix[i][k][j];
}

void free_new_matrix_pbm(pbm pbm_img, uch ***new_matrix) {
  for (uint i = pbm_img.height_start; i < pbm_img.height; i++)
    free(new_matrix[0][i]);
  free(*new_matrix);
}

void free_new_matrix_pgm(pgm pgm_img, uch ***new_matrix) {
  for (uint i = pgm_img.height_start; i < pgm_img.height; i++)
    free(new_matrix[0][i]);
  free(*new_matrix);
}

void free_new_matrix_ppm(ppm ppm_img, uch ****new_matrix) {
  for (uint i = ppm_img.height_start; i < ppm_img.height; i++) {
    for (uint j = ppm_img.width_start; j < ppm_img.width; j++)
      free(new_matrix[0][i][j]);
    free(new_matrix[0][i]);
  }
  free(*new_matrix);
}

void swap(int *number1, int *number2) {
  int aux = *number1;
  *number1 = *number2;
  *number2 = aux;
}

void swap_uint(uint *number1, uint *number2) {
  uint aux = *number1;
  *number1 = *number2;
  *number2 = aux;
}
